<?php

Class modProjectStatusBarHelper {

   /**
    * 
    * @param type $params
    * @return type
    */
    public static function getProjectStatusBar($params = null) {
        $app = JFactory::getApplication();
        $db = JFactory::getDbo();
        $user = JFactory::getUser();
     //  echo JRequest::getVar("project_id"); die;
        $id = $pid = JRequest::getVar("project_id");
        $bidAccepted = false;
        $step = 0;
        $project = JblanceHelper::get('helper.project');  // create an instance of the class FinanceHelper
     
        $config = JblanceHelper::getConfig();
        $return = array();
        $step = 0;

        $appProgress = false;
        $isOwnedOperation = JblanceHelper::checkOwnershipOfOperation($id, 'project');
       //    echo '<pre>'; print_r($isOwnedOperation); die;
        $db = JFactory::getDbo();
        $pj = $project::getProjectDetails($id);
      //  echo $id;
        //   echo '<pre>'; print_r($id); die;;
        $status = $pj->status;
        $freelancer = $pj->assigned_userid == $user->id ? true : false;


        if ($id > 0 && $isOwnedOperation || $freelancer) {

            $pjcat = explode(',', JblanceHelper::getCategoryNames($pj->id_category));
            $apr = $pj->approved;
            $appActivityPhase = false;
            //if not approved or email is not validated yet.
            if ($apr == 0 || $user->emailvalid != '') {
                $approved = "Certification pending";
                $step = 1;
            }
            //if approved and email valid set set approval activity phase to true.
            if ($apr == 1 && $user->emailvalid == '') {
                $approved = "Approved";
                $step = 2;
                $appActivityPhase = true;

                $query = "SELECT * FROM #__jblance_bid WHERE project_id=" . $id . " AND status='COM_JBLANCE_ACCEPTED'";
                $db->setQuery($query);
                $bid = $db->loadAssoc();
                $bId = $bid['id'];
            }

            if ($appActivityPhase && $status == "COM_JBLANCE_FROZEN") {
                $step = 3;
            }
            if ($appActivityPhase && $status == "COM_JBLANCE_CLOSED") {
                $query = "SELECT p.id project_id, p.publisher_userid buyer_id, p.assigned_userid freelancer_id, p.project_title, " .
                        " b.id bid_id, b.amount, b.delivery, b.p_status, b.p_percent, b.p_started, b.p_updated, b.p_ended FROM #__jblance_bid b" .
                        " LEFT JOIN #__jblance_project p ON p.id=b.project_id" .
                        " WHERE b.id=" . $db->quote($bId);

                $db->setQuery($query);
                $row = $db->loadAssoc();
                $step = $row['p_status'] != "COM_JBLANCE_COMPLETED" ? 4 : 5;
            }
        }

//echo $step ; die;
        return $step;
    }
    
    
  

}
