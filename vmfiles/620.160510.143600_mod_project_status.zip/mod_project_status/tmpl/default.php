
<?php
defined('_JEXEC') or die;

$step=  modProjectStatusBarHelper::getProjectStatusBar();
if($step != 0){
		$projectStateBar = '		<div class="steps">
			<span class="line"></span>
			<ul class="fleft">
				<li class="step1';

$step == 1 ? $projectStateBar.=' active' : '';
$step > 1 ? $projectStateBar.=' valid' : '';


$projectStateBar.= '">
				<span class="point"></span><span class="name-step">Validating</span>
				</li>
				<li class="step2 ';
$step == 2 ? $projectStateBar.=' active' : '';
$step > 2 ? $projectStateBar.=' valid' : '';

$projectStateBar.='">
				<span class="point"></span><span class="name-step">Select Developer</span>				
				</li>
				<li class="step3 ';
$step == 3 ? $projectStateBar.=' active' : '';
$step > 3 ? $projectStateBar.=' valid' : '';

$projectStateBar.='">
				<span class="point"></span><span class="name-step">Agreement</span>				
				</li>
			
            <li class="step4 ';
$step == 4 ? $projectStateBar.=' active' : '';
$step > 4 ? $projectStateBar.=' valid' : '';

$projectStateBar.='">
				<span class="point"></span><span class="name-step">Work</span>				
				</li>			
			
			 <li class="step5 ';
$step == 5 ? $projectStateBar.=' active' : '';
$step > 5 ? $projectStateBar.=' valid' : '';

$projectStateBar.='">
				<span class="point"></span><span class="name-step">Rate</span>				
				</li>
			
			</ul>
		</div>';

}else{
   $projectStateBar ='<h3> No project(s) found..!   </h3>'; 
}
echo $projectStateBar;
?>
