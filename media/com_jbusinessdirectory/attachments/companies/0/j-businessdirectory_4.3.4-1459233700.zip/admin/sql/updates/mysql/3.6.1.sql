ALTER TABLE `#__jbusinessdirectory_company_locations` ADD COLUMN `name` VARCHAR(75) NULL  AFTER `id` ;

