ALTER TABLE `#__jbusinessdirectory_applicationsettings` ADD COLUMN `enable_offers` TINYINT(1) NOT NULL DEFAULT 1  AFTER `enable_reviews` ;

