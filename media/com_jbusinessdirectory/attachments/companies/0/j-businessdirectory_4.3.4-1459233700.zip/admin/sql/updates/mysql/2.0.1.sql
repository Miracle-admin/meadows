ALTER TABLE `#__jbusinessdirectory_companies` ADD COLUMN `postalCode` VARCHAR(55) NULL  AFTER `googlep` , ADD COLUMN `mobile` VARCHAR(55) NULL  AFTER `postalCode` ;

