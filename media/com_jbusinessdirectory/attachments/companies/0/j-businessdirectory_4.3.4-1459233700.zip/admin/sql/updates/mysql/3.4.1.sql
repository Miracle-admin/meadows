ALTER TABLE `#__jbusinessdirectory_applicationsettings` ADD COLUMN `order_id` VARCHAR(255) NULL;
ALTER TABLE `#__jbusinessdirectory_applicationsettings` ADD COLUMN `order_email` VARCHAR(255) DEFAULT NULL;

