ALTER TABLE `#__jbusinessdirectory_applicationsettings` ADD COLUMN `nr_images_slide` TINYINT NULL DEFAULT 5  AFTER `captcha` ;

