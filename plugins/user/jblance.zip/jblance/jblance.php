<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  User.joomla
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\Registry\Registry;

/**
 * Joomla User plugin
 *
 * @since  1.5
 */
class PlgUserJblance extends JPlugin
{
function onUserAfterLogin($options)
{
$user=$options['user'];
$app=JFactory::getApplication();
$groups=$user->groups;
//you are developer
if(in_array(13,$groups))
{
$app->redirect(JRoute::_(JUri::root()."index.php?option=com_jblance&view=user&layout=dashboarddeveloper&Itemid=346"));
$app->exit();
}
//you are a company
if(in_array(11,$groups))
{
$app->redirect(JRoute::_(JUri::root()."index.php?option=com_jblance&view=user&layout=dashboard&Itemid=148"));
$app->exit();
}


}	
}
