<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');



class Theme_Filetype_type extends WTypes {
var $filetype=array(

		

		1=> 'PHP',

		2=> 'CSS',

		3=> 'JS',

		

		

  	);
}