<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');



class Theme_Typefolder_type extends WTypes {


	public $typefolder=array(

		
		49=> 'node',			


				101=> 'skin',

		105=> 'tag',
		106=> 'mail',							107=> 'coupon',
		108=> 'order',


		
		1=> 'site',				
		2=> 'admin'				


  	);

}