<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');



class Theme_Type_type extends WTypes {


	public $type=array(


		
		49=> 'Application',			


		
		101=> 'Skin',							106=> 'Mail',					
		105=> 'Widget',							107=> 'Coupon',							108=> 'Order',					
		
		1=> 'Public Site',				
		2=> 'Admin Panel',				
		3=> 'Vendors Area',				
		10=> 'Wordpress',


		50=> 'Mobile',


		201=> 'Vendors custom',

		105=>  'Tag'			

  	);

}