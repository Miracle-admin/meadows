<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');



class Theme_Pagination_type extends WTypes {


	var $pagination=array(



		'1'=> 'Lean',				
		'5'=> 'No total',			
		'11'=> 'Standard',		
		'99'=> 'Complete'		


	 );





 
}