CREATE TABLE IF NOT EXISTS `#__theme_node` (
  `tmid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `namekey` varchar(255) NOT NULL,
  `publish` tinyint(4) NOT NULL DEFAULT '1',
  `premium` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `core` tinyint(3) NOT NULL DEFAULT '0',
  `wid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL,
  `filid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` int(10) unsigned NOT NULL DEFAULT '0',
  `modified` int(10) unsigned NOT NULL DEFAULT '0',
  `availability` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `folder` varchar(100) NOT NULL,
  `params` text NOT NULL,
  `rolid` smallint(5) unsigned NOT NULL DEFAULT '1',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` smallint(5) unsigned NOT NULL DEFAULT '999',
  PRIMARY KEY (`tmid`),
  UNIQUE KEY `UK_theme_node_namekey` (`namekey`),
  KEY `IK_theme_node_type_publish_core_premium` (`type`,`publish`,`core`,`premium`)
) ENGINE=MyISAM   /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci*/;

ALTER TABLE `#__theme_node` ENGINE = INNODB;