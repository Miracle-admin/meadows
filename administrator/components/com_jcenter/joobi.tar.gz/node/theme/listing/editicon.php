<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


WLoadFile( 'listing.butedit' , JOOBI_LIB_HTML );
class Theme_Editicon_listing extends WListings_butedit {
function create(){


	if( $this->getValue('core')){
		WPage::renderBluePrint( 'legend', 'show' );
		$this->content='<span class="jpng-16-show" alt="Show" title="View" border="0"></span>';
		return true;
	}else{
		return parent::create();
	}

}}