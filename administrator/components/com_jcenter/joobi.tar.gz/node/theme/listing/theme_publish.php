<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


WLoadFile( 'listing.publish' , JOOBI_LIB_HTML );
class Theme_Theme_publish_listing extends WListings_publish {

function create(){

	if($this->getValue('premium')==1){

		$this->element->infonly=1;

	}else{

		unset($this->element->infonly);

	}

	return parent::create();

}}