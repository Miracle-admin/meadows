<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


WLoadFile( 'listing.radio' , JOOBI_LIB_HTML );
class Theme_Select_default_theme_listing extends WListings_radio {
function create(){

	if($this->getValue('premium')==1){

		$this->checked=true ;

	}

	parent::create();

	return true;

}}