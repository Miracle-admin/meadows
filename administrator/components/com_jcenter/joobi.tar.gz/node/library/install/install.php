<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


class Library_Node_install extends WInstall {

	public function install(&$object){

		if( !empty( $this->newInstall ) || (property_exists($object, 'newInstall') && $object->newInstall)){


		}else{

			
		}


		return true;


	}

}