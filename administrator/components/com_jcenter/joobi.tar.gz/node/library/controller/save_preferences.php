<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */


defined('JOOBI_SECURE') or die('J....');

























 class WController_save_preferences {











	public function savepref(&$localObj){

 		
 		WTools::checkRobots();



		if( isset($localObj->_dontCallSave)) return true;




		$status=true;

		$this->_loadFromTruc( $localObj );

		
		if( !empty($localObj->generalPreferences)){

			$status=$this->_saveCurrentPref( $localObj->generalPreferences, 'updatePref' );	
		}


		
		if( $status && !empty($localObj->userPreferences)){



			$status=$this->_saveCurrentPref( $localObj->userPreferences, 'updateUserPref' );	
		}


		
		$cache=WCache::get();

		$cache->resetCache( 'Preference' );



		
		return $localObj->showM( $status ,  'save', 1, WModel::get( 'library.preferences', 'sid' ));



	}










	public function resetpref(&$localObj){

		static $newDefaultPreferences=array();



		$this->_loadFromTruc( $localObj );



		if( !empty($localObj->generalPreferences)){

			$this->_loadDefaultPref( 'generalPreferences', $newDefaultPreferences, $localObj );

		}


		if( !empty($localObj->userPreferences)){

			$this->_loadDefaultPref( 'userPreferences', $newDefaultPreferences, $localObj );

		}


		$this->_saveCurrentPref( $newDefaultPreferences, 'updatePref' );	




		$node=WExtension::get( $localObj->wid, 'namekey' );						
		$node=substr( $node, 0, strlen($node)-5 );



		$controllerName=ucfirst($node) . '_Savepref_controller';

		$fileLocation=JOOBI_DS_NODE . $node . DS . 'controller' . DS . $node . '_savepref.php';

		if( file_exists( $fileLocation )){

			include_once( $fileLocation );

			
			if( class_exists( $controllerName )){

				$classPref=new $controllerName;

				if( method_exists( $classPref, 'savepref' )){

					$classPref->_dontCallSave=true;

					$classPref->savepref();

				}
			}
		}


		return true;



	}










	public function save2default(&$localObj){



		$status=true;

		$this->_loadFromTruc( $localObj );



		
		if( !empty($localObj->generalPreferences)){

			$status=$this->_saveCurrentPref( $localObj->generalPreferences, 'updateDefaultPref' );	
		}


		
		return $localObj->showM( $status ,  'savedefault', 1, WModel::get( 'library.preferences', 'sid' ));



	}










	private function _loadFromTruc(&$localObj){



		$trucs=WGlobals::get('trucs', array(), '', 'array');

		
		$localObj->generalPreferences=array();

		$localObj->userPreferences=array();

		if( empty($trucs)) return false;


			if( isset($trucs['c'] )){

				$localObj->generalPreferences=$this->_mergePreferences( $localObj->generalPreferences, $trucs['c'] );

			}
			if( isset($trucs['u'])){

				$localObj->userPreferences=$this->_mergePreferences( $localObj->userPreferences, $trucs['u'] );

			}



	}
















	private function _mergePreferences($currentA,$extraA){

		$merged=array();

		if( !empty($currentA)){

			foreach( $currentA as $key=> $val){

				
				if( isset($extraA[$key])){

					$merged[$key]=array_merge( $currentA[$key], $extraA[$key] );

				}else{

					$merged[$key]=$currentA[$key];

				}
			}
		}


		
		foreach( $extraA as $key=> $val){

			
			if( is_array($val) && !empty($val)){

				WPref::get( $key );

				$nodeName=str_replace( '.', '_', $key);

				foreach( $val as $subKey=> $subVal){

					$preName='P' . strtoupper( $nodeName . '_' . $subKey );

					if( !isset($merged[$key][$subKey]) && constant($preName) !=$subVal ) $merged[$key][$subKey]=$extraA[$key][$subKey];

				}
			}
		}


		return $merged;



	}
















	private function _saveCurrentPref($myPreference,$fctName){

		static $preference=null;



		foreach( $myPreference as $key=> $values){

			$realKey=strtolower( $key );

			WPref::get( $realKey );

			$realKey2=str_replace( '.', '_', $realKey );

			$external[$realKey]=true;

			foreach( $values as $property=> $val){

				$mypref='P' . strtoupper($realKey2.'_'.$property);

				if( !empty($property)  &&

					 (!defined($mypref) || constant($mypref) !=$val )

					){

					if( !isset($preference)){

						$preference=new myPreferences(); 
						
						$preference->setAudit();



					}


					$preference->setup($realKey);

					
					
					if( is_array($val)) $val=trim( implode( ',', $val ), ',' );

					if( !$preference->$fctName( $property, $val )) $status=false;



				}
			}
		}


		return true;



	}












	private function _loadDefaultPref($myPreferenceName,&$newDefaultPreferences,&$localObj){

		static $preferenceM=null;

		static $prefWID=array();



		if( !isset($preferenceM)) $preferenceM=WModel::get( 'library.preferences' );

		
		foreach( $localObj->$myPreferenceName as $key=> $value){

			if( !isset($prefWID[$key])){

				$preferenceM->select( array( 'namekey', 'premium' ));


				$preferenceM->whereE( 'wid', WExtension::get( $key, 'wid'));

				$prefWID[$key]=$preferenceM->load('ol');

			}


			
			if( !empty($prefWID[$key])){

				
				foreach( $prefWID[$key] as $key2=> $value2){

					$prefWIDArranged[$value2->namekey]=$value2->premium;

				}


				foreach( $value as $key2=> $value2){

					$newDefaultPreferences[$key][$key2]=$prefWIDArranged[$key2];

				}
			}


		}


	}


 }
