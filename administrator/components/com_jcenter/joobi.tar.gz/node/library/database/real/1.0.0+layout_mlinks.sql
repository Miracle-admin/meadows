CREATE TABLE IF NOT EXISTS `#__layout_mlinks` (
  `mid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `yid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `icon` varchar(50) NOT NULL,
  `action` varchar(150) NOT NULL,
  `parent` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(3) unsigned NOT NULL DEFAULT '99',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `publish` tinyint(4) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `private` tinyint(4) NOT NULL DEFAULT '0',
  `position` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `core` tinyint(4) NOT NULL DEFAULT '1',
  `rolid` smallint(5) unsigned NOT NULL DEFAULT '1',
  `namekey` varchar(100) NOT NULL,
  `ref_wid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `faicon` varchar(50) NOT NULL,
  `color` varchar(15) NOT NULL,
  `xsvisible` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `xshidden` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `devicevisible` varchar(100) NOT NULL,
  `devicehidden` varchar(100) NOT NULL,
  PRIMARY KEY (`mid`),
  UNIQUE KEY `UK_layout_menus_namekey` (`namekey`),
  KEY `layout_mlinks_index_yid_publish_level_rolid_ordering` (`yid`,`level`,`publish`,`ordering`,`rolid`)
) ENGINE=MyISAM   /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci*/;

ALTER TABLE `#__layout_mlinks` ENGINE = INNODB;