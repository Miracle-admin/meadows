CREATE TABLE IF NOT EXISTS `#__joobi_preferences` (
  `namekey` varchar(50) NOT NULL,
  `wid` smallint(5) unsigned NOT NULL,
  `text` text,
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rolid` smallint(5) unsigned NOT NULL DEFAULT '1',
  `premium` text,
  PRIMARY KEY (`wid`,`namekey`)
) ENGINE=InnoDB  /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci*/;

ALTER TABLE `#__joobi_preferences` ENGINE = INNODB;