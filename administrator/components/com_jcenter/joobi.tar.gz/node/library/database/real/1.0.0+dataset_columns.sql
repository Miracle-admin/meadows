CREATE TABLE IF NOT EXISTS `#__dataset_columns` (
  `dbcid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dbtid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `pkey` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `checkval` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attributes` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mandatory` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `default` varchar(50) NOT NULL,
  `ordering` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rolid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `created` int(10) unsigned NOT NULL DEFAULT '0',
  `extra` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `size` decimal(8,0) NOT NULL DEFAULT '0',
  `export` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `namekey` varchar(50) NOT NULL,
  `core` tinyint(4) NOT NULL DEFAULT '1',
  `columntype` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `indexed` tinyint(4) NOT NULL DEFAULT '0',
  `noaudit` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`dbcid`),
  UNIQUE KEY `UK_dataset_columns` (`namekey`),
  UNIQUE KEY `UK_dataset_columns_dbtid` (`name`,`dbtid`)
) ENGINE=MyISAM   /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci*/;

ALTER TABLE `#__dataset_columns` ENGINE = INNODB;