CREATE TABLE IF NOT EXISTS `#__filters_node` (
  `flid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `bktbefore` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `map` varchar(20) NOT NULL,
  `condopr` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `bktafter` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `logicopr` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `publish` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `refmap` varchar(30) NOT NULL,
  `ref_sid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `typea` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `typeb` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `namekey` varchar(50) NOT NULL,
  `name` varchar(40) NOT NULL,
  `yid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`flid`),
  UNIQUE KEY `UK_filters_node_namekey` (`namekey`),
  KEY `IX_filters_node_yid` (`yid`),
  KEY `IX_filters_node_sid` (`sid`)
) ENGINE=MyISAM   /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci*/;

ALTER TABLE `#__filters_node` ENGINE = INNODB;