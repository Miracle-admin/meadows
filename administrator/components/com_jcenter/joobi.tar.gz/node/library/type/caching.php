<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');



class Library_Caching_type extends WTypes {


	var $caching=array(

		 '10'=> 'Maximum',	
		 '7'=> 'Standard',	
		 '3'=> 'Minimum',		
		'0'=> 'None'			
	  );


}