<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');















 class Library_Sql_type extends WTypes {

	public $type=array(

		10=> 'mysql',
		15=> 'mysqli',
		20=> 'posgres',
		30=> 'oracle'
	  );


 }


