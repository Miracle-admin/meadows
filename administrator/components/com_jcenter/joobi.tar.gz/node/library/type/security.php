<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');















 class Library_Security_type extends WTypes {

	public $security=array(
		 '10'=> 'High',
		 '5'=> 'Medium',
		 '1'=> 'Low'
	  );


 }


