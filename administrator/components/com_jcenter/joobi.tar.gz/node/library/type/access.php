<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');















 class Library_Access_type extends WTypes {

	var $access=array(
		 '0'=> 'Public',
		 '1'=> 'Registered',
		 '2'=> 'Special'
	  );


 }


