<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


class Users_Users_login_registration_view extends Output_Forms_class {
function prepareView(){





	$uid=WUser::get( 'uid' );



	$usersAddon=WAddon::get( 'users.' . WPref::load( 'PUSERS_NODE_FRAMEWORK_FE' ));

	if( !empty($uid)){

		$usersAddon->goProfile( $uid );

		return true;

	}




	$allowLogin=WPref::load( 'PUSERS_NODE_LOGINALLOW' );



	if( empty($allowLogin)){

		$this->removeElements( 'users_login_registration_login' );

		$noLogin=true;

	}




	$allowRegistration=WPref::load( 'PUSERS_NODE_REGISTRATIONALLOW' );

	if( empty($allowRegistration)){



		$this->removeElements( 'users_login_registration_register' );



		if( !empty($noLogin)){

			$this->userE('1402327858JCQW');

		}


	}else{



		
		$captcha=WPref::load( 'PUSERS_NODE_USECAPTCHA' );

		if( empty($captcha)) $this->removeElements( 'users_login_registration_register_captcha' );



		$showMobile=WPref::load( 'PUSERS_NODE_USEMOBILE' );

		if( !$showMobile ) $removeElementsA[]='users_login_registration_register_mobile';

		$showLanguage=WPref::load( 'PUSERS_NODE_USELANGUAGE' );

		if( !$showLanguage ) $removeElementsA[]='users_login_registration_register_language';

		$showTimezone=WPref::load( 'PUSERS_NODE_USETIMEZONE' );

		if( !$showTimezone ) $removeElementsA[]='users_login_registration_register_timezone';

		$showCurrency=WPref::load( 'PUSERS_NODE_USECURRENCY' );

		if( !$showCurrency ) $removeElementsA[]='users_login_registration_register_curid';

		$showAvatar=WPref::load( 'PUSERS_NODE_USEAVATAR' );

		if( !$showAvatar ) $removeElementsA[]='users_login_registration_register_filid';

		$showHTML=WPref::load( 'PUSERS_NODE_USEHTMLEMAIL' );

		if( !$showHTML ) $removeElementsA[]='users_login_registration_register_html';



	}




	return true;



}}