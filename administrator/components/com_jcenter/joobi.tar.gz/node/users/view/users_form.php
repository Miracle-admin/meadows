<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


class Users_Users_form_view extends Output_Forms_class {
function prepareView(){



		
		$removeElementsA=array();

		if( !IS_ADMIN){



			$showMobile=WPref::load( 'PUSERS_NODE_USEMOBILE' );

			if( !$showMobile ) $removeElementsA[]='users_form_users_mobile';

			$showLanguage=WPref::load( 'PUSERS_NODE_USELANGUAGE' );

			if( !$showLanguage ) $removeElementsA[]='users_form_users_lgid';

			$showTimezone=WPref::load( 'PUSERS_NODE_USETIMEZONE' );

			if( !$showTimezone ) $removeElementsA[]='users_form_users_timezone';

			$showCurrency=WPref::load( 'PUSERS_NODE_USECURRENCY' );

			if( !$showCurrency ) $removeElementsA[]='users_form_users_curid';

			$showAvatar=WPref::load( 'PUSERS_NODE_USEAVATAR' );
			if( !$showAvatar ) $removeElementsA[]='users_form_users_filid';


		}


		$roleC=WRole::get();

		if( WRole::hasRole( 'manager' )){

			
		}




		
		$eid=$this->getValue( 'uid' );

		if( !empty($eid)){

			$uid=WUser::get( 'uid' );

			
			if( $eid==$uid ) $removeElementsA[]='users_form_users_block';







		}




		if( !empty($removeElementsA)) $this->removeElements( $removeElementsA );



		return true;



	}}