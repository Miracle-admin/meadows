<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


class Users_Parent_class extends WClasses {






	public function getUser($userId,$loadFrom=''){		}









	public function goRegister($itemId){
	}




	public function goLogin($itemId=null,$message=''){
	}





	public function goLogout($itemId=null,$message=''){

		$usersAddon=WAddon::get( 'api.' . JOOBI_FRAMEWORK . '.user' );
		$usersAddon->logout();

		$logout=WPref::load( 'PUSERS_NODE_LOGOUT_LANDING' );
		if( empty($logout)) $logout='home';

		WPages::redirect( $logout );

	}





	public function goProfile($uid=null){
		if( empty($uid)) $uid=WUser::get( 'uid' );
		$this->showUserProfile( $uid, false );
	}





	public function checkPlugin(){
	}












	public function ghostAccount($email,$password,$name='',$username=null,$automaticLogin=false,$createJoobiUser=true,$sendPwd=false,$extraPrams=null){
	}




	public function addUserRedirect(){
	}








	public function showUserProfile($eid,$onlyLink=false){

		$controller=WGlobals::get( 'controller' );
		$task=WGlobals::get( 'task' );
		if( 'users'==$controller && 'dashboard'==$task ) $link=false;
		else $link='controller=users&task=dashboard&eid=' . $eid;

		if( $onlyLink ) return $link;

		if( !empty($link)) WPages::redirect( $link );

	}





	public function editUserRedirect($eid,$onlyLink=false){
	}





	public function getPicklistElement(){
	}






	public function automaticLogin($username,$password){
	}





	public function checkConfirmationRequired(){
	}






	public function getAvatar($uid){
	}
}