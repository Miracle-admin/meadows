<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


class Users_Node_model extends WModel {


	protected $_updateCMS=true;

	



	protected $_emailNewPassword=false;


		protected $_syncContacts=true;

	protected $_checkEmailValidity=true;


		private $_password=null;


	private $_roleC=null;








	function __construct(){



		$myImageO=new stdClass;
		$myImageO->fileType='images';
		$myImageO->folder='media';
		$myImageO->path='images' . DS . 'users';
		$myImageO->secure=false;
		$prodPref=WPref::load( 'PUSERS_NODE_IMGFORMAT' );
		if( !empty($prodPref)){
			$imgFormat=explode( ',', $prodPref );
		}		$myImageO->format=( !empty($imgFormat)) ? $imgFormat : array( 'jpg', 'png', 'gif', 'jpeg');

				$myImageO->thumbnail=1;			$myImageO->maxSize=PUSERS_NODE_IMGMAXSIZE * 1028;
		$myImageO->maxHeight=( PUSERS_NODE_MAXPH > 50 ? PUSERS_NODE_MAXPH : 50 );
		$myImageO->maxWidth=( PUSERS_NODE_MAXPW > 50 ? PUSERS_NODE_MAXPW : 50 );
		$myImageO->maxTHeight=( PUSERS_NODE_SMALLIH > 20 ? array( PUSERS_NODE_SMALLIH ) : 20 );
		$myImageO->maxTWidth=( PUSERS_NODE_SMALLIW > 20 ? array( PUSERS_NODE_SMALLIW ) : 20 );
		$myImageO->watermark=PUSERS_NODE_WATERMARKITEM;
		$myImageO->storage=PUSERS_NODE_FILES_METHOD_PHOTOS;

		$this->_fileInfo=array();
		$this->_fileInfo['filid']=$myImageO;


		parent::__construct();



	}








	public function setEmailValidation($validate=true){

		$this->_checkEmailValidity=$validate;

	}






	public function updateFrameworkUser($update=false){
		$this->_updateCMS=$update;
	}






	public function emailNewPassword($pwd=false){
		$this->_emailNewPassword=$pwd;
	}








	function validate(){

		$usersEmailC=WClass::get( 'users.email' );
		if( $this->_checkEmailValidity && !empty($this->email) && !$usersEmailC->validateEmail( $this->email )){
			$message=WMessage::get();
			$message->historyE('1298350399EIUD');
		}

				if( !empty($this->x['password'])){
			if( $this->x['password'] !=$this->x['password_confirmed']){
				$message=WMessage::get();
				$message->historyE('1401465958GTFQ');
			}

			if( empty($this->rolid)){
								if( empty( $this->uid )){
										$rolid=WPref::load( 'PUSERS_NODE_REGISTRATIONROLE' );
				}else{
										$rolid=WUser::get( 'rolid', $this->uid );
				}
			}else{
				$rolid=$this->rolid;
			}
									if( !isset($this->_roleC)) $this->_roleC=WRole::get();
			$isManager=$this->_roleC->compareRole( $rolid, 'manager' );
			$strenght=( $isManager ? WPref::load( 'PUSERS_NODE_PWD_STRENGTH_ADMIN' ) : WPref::load( 'PUSERS_NODE_PWD_STRENGTH_REGISTER' ));


			$usersRegsiterC=WClass::get( 'users.register' );
			$error=$usersRegsiterC->checkPassword( $this->x['password'], $strenght );
			if( !empty($error)){
				$message=WMessage::get();
				$message->historyE( $error );
			}
						$this->password=$usersRegsiterC->generateHashPassword( $this->x['password'] );

						$this->_password=$this->x['password'];

		}
		WController::trigger( 'users', 'onvalidate', $this );


		return true;


	}










	function addValidate(){

		
		if( empty( $this->email )) return false;


				$sidV=WModel::get( 'vendors', 'sid' );
		$propUsed='C' . $sidV;
		unset( $this->$propUsed );
		$sidV=WModel::get( 'vendorstrans', 'sid' );
		$propUsed='C' . $sidV;
		unset( $this->$propUsed );


		$this->validateDate( 'registerdate' );
		if( empty($this->registerdate)) $this->registerdate=time();


		if( empty( $this->username )){
			$PUSERS_NODE_USERNAMEDEFAULT=WPref::load( 'PUSERS_NODE_USERNAMEDEFAULT' );
			if( 'email'==$PUSERS_NODE_USERNAMEDEFAULT ) $this->username=$this->email;
			else {
				$count=0;
				do {
					$count++;
					$this->username=WTools::randomString( 10, false );
					$unique=$this->_uniqueUsername( $this->username );
				} while ( !$unique && $count < 10 );
								if( $count==10 ) $this->username .='_' . time();
			}		}else{
						$usersM=WModel::get( 'users' );
			$usersM->whereE( 'username', $this->username );
			$existinUID=$usersM->load( 'lr', 'uid' );
			if( !empty($existinUID)){
				$this->historyE('1418689202ISSQ');
			}
		}

		if( empty( $this->name )) $this->name=$this->username;



						$onRegsitration=WGlobals::set( 'userOnRegister', false, 'global' );
		if( $onRegsitration && !isset($this->rolid)){
			$this->rolid=WPref::load( 'PUSERS_NODE_REGISTRATIONROLE' );
		}

		
		if( empty( $this->rolid )){
			$this->rolid=WRole::getRole(  'visitor' );
		}


		if( !isset($this->_roleC)) $this->_roleC=WRole::get();
		$isRegister=$this->_roleC->compareRole( $this->rolid, 'registered' );
		if( $isRegister){

			$this->registered=1;

						if( empty( $this->password )){

												$usersRegsiterC=WClass::get( 'users.register' );
				$password=WTools::randomString( 14, true );
				$this->password=$usersRegsiterC->generateHashPassword( $password );

				
			}
		}
				if( !isset($this->confirmed)) $this->confirmed=0;

		$activationmethod=WPref::load( 'PUSERS_NODE_ACTIVATIONMETHOD' );			switch( $activationmethod){
			case 'admin':
				if( isset($this->blocked)) $this->blocked=1;
				break;
			case 'self':
				if( isset($this->blocked)) $this->blocked=1;
								break;
			default:
								if( isset($this->blocked)) $this->blocked=0;
				break;
		}

				$memberSessionC=WUser::session();
		$ip=$memberSessionC->getIP();

		if( !empty( $ip )){

			if( !isset($this->ip)) $this->ip=$ip;
									$ipLookupC=WClass::get( 'iptracker.lookup', null, 'class', false );
			if( is_object($ipLookupC)){
				$localization=$ipLookupC->detectIP( $ip );

				if( !isset($this->timezone) || $this->timezone==999){
					if( isset($localization->country->timezone)){
						$this->timezone=$localization->country->timezone;
					}				}
				if( !isset($this->ctyid)){
										if( !empty($localization->country->ctyid)) $this->ctyid=$localization->country->ctyid;
				}			}
		}

		$this->returnId();
		return true;


	}












	function editValidate(){

		
	
		return true;

	}












	function addExtra(){

	

		if( $this->_syncContacts){
						$existOrganization=WExtension::exist( 'contacts.node' );
			if( !empty($existOrganization)){
				$contactsDetailsM=WModel::get( 'contacts.details' );
				$contactsDetailsM->setVal( 'uid', $this->uid );
				if( !empty($this->name)){
					$nameA=explode( ' ', $this->name );
					$count=count( $nameA );
					$firstName='';
					$middleName='';
					$lastName='';
					if( $count <=1){
						$lastName=$nameA[0];
					}elseif( $count <=2){
						$firstName=$nameA[0];
						$lastName=$nameA[1];
					}else{
						$firstName=array_shift($nameA);
						$middletName=array_shift($nameA);
						$lastName=implode( ' ', $nameA );
					}
					if( !empty($firstName)) $contactsDetailsM->setVal( 'first_name', $firstName );
					if( !empty($middletName)) $contactsDetailsM->setVal( 'middle_name', $middletName );
					if( !empty($lastName)) $contactsDetailsM->setVal( 'last_name', $lastName );

				}
				$contactsDetailsM->insertIgnore();

			}
		}


				$usersRegisterC=WClass::get( 'users.register' );

						if( !empty( $this->registered )){

			if( !empty($this->_x['password'])) $password=$this->_x['password'];
			else $password='';

						$frameworkFE=WPref::load( 'PUSERS_NODE_FRAMEWORK_FE' );
			if( !IS_ADMIN && in_array( $frameworkFE, array( 'users', 'contacts' ))){
								$activationmethod=WPref::load( 'PUSERS_NODE_ACTIVATIONMETHOD' );					
				switch( $activationmethod){
					case 'admin':
												$usersRegisterC=WClass::get( 'users.register' );
						if( !empty( $this->uid )){
							$usersRegisterC->sendAdminApproval( $this->uid );
							$emailpwd=WPref::load( 'PUSERS_NODE_EMAILPWD' );
							if( !empty($emailpwd) || $this->_emailNewPassword){
								$usersRegisterC->emailPassword( $this->uid, $password );
							}						}						break;
					case 'self':
												$usersRegisterC=WClass::get( 'users.register' );
						if( !empty( $this->uid )){
							$usersRegisterC->sendSelfApproval( $this->uid, $password );
							if( $this->_emailNewPassword ) $usersRegisterC->emailPassword( $this->uid, $password );
						}						break;
					default:

						if( empty( $this->blocked )){
														if( !empty($password)){
								if( !empty( $this->uid )) $usersRegisterC->emailPassword( $this->uid, $password );
								else $this->userE('1401818484FRIA');
							}						}												break;
				}
			}

		}

				$usersRegisterC->notifyAdmin( $this->uid );


		$this->_updateCMSUser();

		return true;



	}






	function editExtra(){

				if( !empty($this->id)){
			$id=$this->id;
		}else{
			$id=WUser::get( 'id', $this->uid );
		}
		$this->_updateCMSUser( $id );

		return true;

	}







	private function _updateCMSUser($id=0){

		if( !$this->_updateCMS ) return true;

		$framworkRole=WPref::load( 'PUSERS_NODE_FRAMEWORKROLE' );
				if( empty($framworkRole)){
			$framworkRole='registered';
		}
		$rolid=( !empty($this->rolid) ? $this->rolid : WUser::get('rolid'));
		if( !isset($this->_roleC)) $this->_roleC=WRole::get();
		$isRegister=$this->_roleC->compareRole( $rolid, $framworkRole );

		if( $isRegister){

						WGlobals::set( 'syncUserFlag', true, 'global' );

						$extraPrams=new stdClass;
			if( isset($this->lgid)) $extraPrams->lgid=$this->lgid;
			if( isset($this->blocked)) $extraPrams->blocked=$this->blocked;
			if( isset($this->rolid)) $extraPrams->rolid=$this->rolid;
			if( isset($this->activation)) $extraPrams->activation=$this->activation;
			if( isset($this->registerdate)) $extraPrams->registerdate=$this->registerdate;
			if( !empty($id)) $extraPrams->id=$id;

			$usersAddon=WAddon::get( 'users.' . JOOBI_FRAMEWORK );
			$id=$usersAddon->ghostAccount( $this->email, $this->_password, $this->name, $this->username, false, false, false, $extraPrams );

						if( !empty($id)){
				$usersM=WModel::get( 'users' );
				$usersM->whereE( 'uid', $this->uid );
				$usersM->setVal( 'id', $id );
				$usersM->update();
			}
		}
	}








	function extra(){

		WController::trigger( 'users', 'onExtra', $this );

		return true;

	}












	function deleteValidate($eid=0){

		if( $eid==WUser::get('uid')){
			$this->userE('1402327860NWWM');
			return false;
		}
		$this->_deleteInfoO=WUser::get( 'data', $eid );


		WController::trigger( 'users', 'deleteValidate', $this );

		return true;

	}












	function deleteExtra($eid=0){
				$usersAddon=WAddon::get( 'api.' . JOOBI_FRAMEWORK . '.user' );
		if( !empty($this->_deleteInfoO)) $status=$usersAddon->deleteUser( $this->_deleteInfoO );


		WController::trigger( 'users', 'deleteExtra', $this );


		return true;


	}






	private function _uniqueUsername($username){
		$uid=WUser::get( 'uid', $username );
		return $uid;
	}
}