<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


class Users_edit_controller extends WController {


	function edit(){



		$eid=WGlobals::getEID();






		$frameworkUsed=IS_ADMIN ? WPref::load( 'PUSERS_NODE_FRAMEWORK_BE' ) : WPref::load( 'PUSERS_NODE_FRAMEWORK_FE' );

		if( empty($frameworkUsed)) $frameworkUsed=JOOBI_FRAMEWORK;



		$usersAddon=WAddon::get( 'users.' . $frameworkUsed );

		if( !empty($usersAddon)) $usersAddon->editUserRedirect( $eid );



		return parent::edit();



	}}