CREATE TABLE IF NOT EXISTS `#__role_members` (
  `rolid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`uid`,`rolid`)
) ENGINE=MyISAM  /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci*/;

ALTER TABLE `#__role_members` ENGINE = INNODB;