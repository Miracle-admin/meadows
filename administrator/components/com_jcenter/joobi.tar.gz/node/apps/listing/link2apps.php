<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


class Apps_Link2apps_listing extends WListings_standard {
function create(){

	$namekey=$this->getValue( 'namekey' );

	$nA=explode( '.', $namekey );

	$folder=$nA[0];

	$this->content='<a href="' . JOOBI_INDEX . '?' . JOOBI_URLAPP_PAGE . '=' . WApplication::getAppLink( $folder ) .'&controller='.$folder.'">'.$this->value.'</a>';

	return true;

}}