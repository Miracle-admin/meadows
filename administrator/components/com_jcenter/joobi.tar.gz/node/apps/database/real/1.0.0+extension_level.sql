CREATE TABLE IF NOT EXISTS `#__extension_level` (
  `lwid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `namekey` varchar(50) NOT NULL,
  PRIMARY KEY (`lwid`),
  UNIQUE KEY `UK_extension_level_wid_level` (`wid`,`level`),
  UNIQUE KEY `NamekeyExtensionLevel` (`namekey`)
) ENGINE=MyISAM   /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci*/;

ALTER TABLE `#__extension_level` ENGINE = INNODB;