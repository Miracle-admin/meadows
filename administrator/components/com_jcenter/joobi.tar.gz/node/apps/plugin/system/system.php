<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');






class Apps_System_plugin extends WPlugin {




function onAfterRender(){

		if( ! in_array( JOOBI_FRAMEWORK, array( 'joomla16', 'joomla30' )) ) return true;

	$debugTrace=WGlobals::get( 'debugTraces', '', 'global' );

	if( !empty($debugTrace)){
		if( !defined('PLIBRARY_NODE_DBGERR')) WPref::get( 'library.node' );
				if( WUser::isRegistered()){
			$debug=PLIBRARY_NODE_DBGERR;
			$debug=$debug || PLIBRARY_NODE_DBGQRY;
		}else{
			$debug=PLIBRARY_NODE_DBGERRGUEST;
			$debug=$debug || PLIBRARY_NODE_DBGQRYGUEST;
		}
		if( $debug){
			$debugHTML='<div class="clr"></div><div class="debug">';
			$debugHTML .= $debugTrace;
			$debugHTML .= '</div>';

			$body=JResponse::getBody();
			$body .=$debugHTML;
			JResponse::setBody($body);

			WGlobals::set( 'debugTraces', '', 'global', true );				
		}
	}
}
}