<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');






class Apps_reinstall_controller extends WController {




	function reinstall(){

				if( empty($_SESSION['joobi']['install_status'])){

			$wid=WGlobals::getEID();
			$helperC=WClass::get( 'apps.helper' );
			$appExtensions=$helperC->getAppsDependencies( $wid );

						$appsM=WModel::get( 'apps' );
			$appsM->updatePlus( 'version', -1 );
			$appsM->whereIn( 'namekey', $appExtensions );
			$appsM->update();

		}
		$install=WClass::get( 'install.process' );
		$status=$install->instup();

				$extensionHelperC=WCache::get();
		$extensionHelperC->resetCache();

		return $status;
	}
}