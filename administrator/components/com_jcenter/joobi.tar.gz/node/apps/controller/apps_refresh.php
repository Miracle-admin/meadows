<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');






WLoadFile( 'apps.controller.apps_listing' );
class Apps_refresh_controller extends Apps_Listing_controller {










	function refresh(){



		$netcomServerC=WClass::get('netcom.server');
		$myDistribServer=$netcomServerC->checkOnline();
		if( $myDistribServer===false ) return true;


				$refresh=WClass::get( 'apps.refresh' );

		if( !$refresh->getDataAndRefresh( false )){

			return false;

		}


		
		$install=WClass::get( 'install.process' );

		$install->updatePref(0);
		if( isset( $_SESSION['joobi'] )) unset( $_SESSION['joobi'] );


		
		$apps=WGlobals::get('apps','');



		if( !empty($apps)){
			$appsM=WModel::get( 'apps' );
			$appsM->whereE( 'publish' , 1 );
			$appsM->whereE( 'type', 1 );
			$appsList=$appsM->load( 'lra', 'namekey' );



			$appslevelM=WModel::get( 'apps.level' );

						foreach( $appsList as $app){

				if( $app=='jcenter.application' ) continue; 
								$appslevelM->wid=WExtension::get( $app, 'wid' );
				$appslevelM->level=50;
				$appslevelM->namekey=$app . 50;
				$appslevelM->setIgnore();
				$appslevelM->insert();

				
			}

			$apps=explode( '.', $apps );
			$app=$apps[0];
			if( strpos( $app, '_' )===false ) $app.='.application';
			else $app=str_replace( '_', '.', $app );

						$application=WExtension::get( $app, 'data' );

			if( !empty( $application )){
								WPref::get( $application->namekey );


								$constant='P'.strtoupper(str_replace( '.', '_', $application->namekey )).'_INSTALLED';

				if( defined( $constant )){
					$myConstant=constant( $constant );

										if( $myConstant<1){

						$mycontroller=explode( '.', $apps );
						$url=WPage::routeURL( 'controller=' . $application->folder . '&task=setup', 'smart', 'default', false, true, $application->folder );
						WPages::redirect( $url );
					}				}
			}

		}

				$cache=WCache::get();
		$cache->resetCache();


		
		$mess=WMessage::get();

		$mess->userS('1229651871ADBI');


				$appsRefreshC=WClass::get( 'apps.refresh' );
		$appsRefreshC->checkNewDistributionServer( true );



		return true;


	}



}