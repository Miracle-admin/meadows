<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');






class Apps_listing_controller extends WController {










	function listing(){


				if( isset($_SESSION['joobi']['first_install'])) unset( $_SESSION['joobi']['first_install'] );

		$install=WClass::get( 'install.process' );

		$install->updatePref( 0 );



		return true;

	}





}