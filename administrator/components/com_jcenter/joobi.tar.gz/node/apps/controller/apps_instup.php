<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');





class Apps_instup_controller extends WController {








	function instup(){



		$install=WClass::get( 'install.process' );

		$status=$install->instup();


				$extensionHelperC=WCache::get();
		$extensionHelperC->resetCache();

		return $status;

	}

}