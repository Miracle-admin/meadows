<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');




 class Apps_Checkout_class extends WClasses {




	function memberCheckin($uid=0){
		return true;


		if( $uid<1 ) return false;
		$checkoutM=WModel::get('checkout');
		$checkoutM->whereE( 'uid', $uid );
		$checkoutM->delete();
		return true;

	}



}