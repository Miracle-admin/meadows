<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


class Apps_Apimessage_form extends WForms_default {
function create(){



	$meesage=WText::t('1418159317GYIO');



	$this->content=$meesage ;



	return true;



}}