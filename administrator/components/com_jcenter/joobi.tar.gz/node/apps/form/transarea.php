<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');


WLoadFile( 'form.textarea' , JOOBI_LIB_HTML );
class Apps_Transarea_form extends WForm_textarea {

	function create(){



		$wid=WGlobals::getEID();

		$lgid=WGlobals::get( 'trlgid' );



		$translationExportlangC=WClass::get('translation.exportlang');

		$translationExportlangC->getText2Translate( $lgid, $lgid, $wid, false );

		$this->value=$translationExportlangC->createLanguageString();



		return parent::create();



	}

}