<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');






class Apps_Color_type extends WTypes {
	var $color=array(
		'std'=> 'Standard',
		'admin'=> 'Same as Admin',
		'blue'=> 'Blue',
		'red'=> 'Red',
		'orange'=> 'Orange',
		'green'=> 'Green',
		'purple'=> 'Purple',
		'yellow'=> 'Yellow'
	 );

}