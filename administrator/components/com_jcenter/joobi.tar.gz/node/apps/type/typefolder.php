<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');















 class Apps_Typefolder_type extends WTypes {

	public $typefolder=array(
		'1'=> 'node',
		'2'=> 'node',
		'3'=> 'node',
		'25'=> 'module',
		'50'=> 'plugin',
		'60'=> 'action',
		'75'=> 'addon',
		'76'=> 'scheduler',
		'77'=> 'tag',
		'78'=> 'mailbox',
		'80'=> 'payment',

		'95'=> 'class',
		'100'=> 'user|theme|node',
		'101'=> 'user|theme|admin',
		'102'=> 'user|theme|site',
		'103'=> 'user|theme|mobile',

		'106'=> 'user|theme|mail',
		'107'=> 'user|theme|coupon',
		'108'=> 'user|theme|order',

	'125'=> 'lib',
	    '110'=> 'type',
	    '111'=> 'object',
		'150'=> 'node',
		'175'=> 'inc',
		'200'=> 'api',
		'225'=> 'joobiinstaller',
		'250'=> 'fonts',

		'300'=> 'language',
		'350'=> 'cms',

		'76'=> 'scheduler',

		'77'=> 'tag',

		'78'=> 'mailbox'
	 );

 }


