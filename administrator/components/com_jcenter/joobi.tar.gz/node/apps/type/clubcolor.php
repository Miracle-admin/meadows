<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');















 class Apps_Clubcolor_type extends WTypes {

	public $clubcolor=array(

		21=> 'warning',
		23=> 'info',
		25=> 'primary',
		27=> 'success',

		31=> 'warning',
		33=> 'info',
		35=> 'primary',
		37=> 'success'
	  );

 }


